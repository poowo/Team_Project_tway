$(document).ready(function(){
    $('.info_title').click(function(){
        $('.info_text').slideToggle('fast');
    });
});